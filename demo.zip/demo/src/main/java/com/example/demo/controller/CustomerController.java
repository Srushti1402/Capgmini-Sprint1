package com.example.demo.controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Customer;
import com.example.demo.model.Restaurant;
import com.example.demo.repository.CustomerRepository;
import com.example.demo.repository.RestaurantRepository;
import com.example.demo.service.CustomerService;
@RestController
@RequestMapping("/customer")
public class CustomerController {
	@Autowired
	CustomerService service;
	@Autowired
	private CustomerRepository customerrepository;
	@Autowired
	private RestaurantRepository restrepository;
	
	
	@GetMapping("/customer/{id}")
	  public ResponseEntity<Customer> getCustomerById(@PathVariable("id") long id) {
	    Customer customer = customerrepository.findById(id)
	        .orElseThrow(() -> new RuntimeException("Not found Customer with id = " + id));
	    return new ResponseEntity<>(customer, HttpStatus.OK);
	  }
	
	@RequestMapping(value="/Customer/{id}",method=RequestMethod.DELETE)
	public String deleteCustomer(@PathVariable long id)
	{
		Optional<Customer> i=customerrepository.findById(id);
		if(i==null)
			throw new RuntimeException("Customer Id not found");
		customerrepository.deleteById(id);
		return "deleted Customer "+id;
	}
	
	@GetMapping("/allcustomers/{name}")
	public ResponseEntity<List<Restaurant>> getAllCustomerByRestaurantName(@PathVariable String name)
	{
		List<Restaurant> list=restrepository.findByRestaurantName(name);
		return new ResponseEntity<List<Restaurant>>(list,new HttpHeaders(),HttpStatus.OK);
	}
	
	@GetMapping("/allcustomers")
	public ResponseEntity<List<Customer>> getAllCustomers()
	{
		List<Customer> list=service.viewAllCustomers();
		return new ResponseEntity<List<Customer>>(list,new HttpHeaders(),HttpStatus.OK);
	}
	
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public Customer addCustomer(@RequestBody Customer cust)
	{
	        return (service.addCustomer(cust));
	}

}
