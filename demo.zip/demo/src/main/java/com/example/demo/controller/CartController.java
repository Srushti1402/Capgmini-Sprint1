package com.example.demo.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Bill;
import com.example.demo.model.FoodCart;
import com.example.demo.model.Item;
import com.example.demo.service.CartService;

@RestController
@RequestMapping("/cart")
public class CartController {
	
	@Autowired
	CartService service;
	
	@GetMapping("/allcarts")
	public ResponseEntity<List<FoodCart>> getAllCarts()
	{
		List<FoodCart> list=service.viewCarts();
		return new ResponseEntity<List<FoodCart>>(list,new HttpHeaders(),HttpStatus.OK);
	}
	
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public FoodCart addCart(@RequestBody FoodCart cart)
	{
		return service.addCart(cart);
	}
	
}
