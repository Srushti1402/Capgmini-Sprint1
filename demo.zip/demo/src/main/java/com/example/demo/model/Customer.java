package com.example.demo.model;

import javax.persistence.*;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Table(name="customer")
public class Customer {
	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="customerid")
	private long customerid;
	
	@Column(name="firstname")
	private String firstname;
	
	@Column(name="lastname")
	private String lastname;
	
	@Column(name="age")
	private int age;
	
	@Column(name="gender")
	private String gender;
	
	@Column(name="mobilenumber")
	private String mobilenumber;
	
	@Column(name="email")
	private String email;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "addressid", referencedColumnName = "addressid")
	@OnDelete(action = OnDeleteAction.CASCADE)
    private Address address;
	
	@Transient
	@OneToOne(mappedBy = "customer",cascade = CascadeType.ALL, orphanRemoval = true,fetch = FetchType.LAZY)
    private FoodCart foodcart;
	
	public Customer()
	{}

	public Customer(String firstname, String lastname, int age, String gender, String mobileno, String email,
			Address address) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.age = age;
		this.gender = gender;
		this.mobilenumber = mobileno;
		this.email = email;
		this.address = address;
	}

	public long getCustomerid() {
		return customerid;
	}

	public String getFirstname() {
		return firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public int getAge() {
		return age;
	}

	public String getGender() {
		return gender;
	}

	public String getMobileno() {
		return mobilenumber;
	}

	public String getEmail() {
		return email;
	}

	public Address getAddress() {
		return address;
	}

	public void setCustomerid(long customerid) {
		this.customerid = customerid;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setMobileno(String mobileno) {
		this.mobilenumber = mobileno;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
	

}
