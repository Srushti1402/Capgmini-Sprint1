package com.example.demo.model;

import java.time.LocalDateTime;

import javax.persistence.*;

@Entity
@Table(name="orderdetails")
public class OrderDetails {
	
	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="orderid")
	private long orderid;
	
	@Column(name="orderdate")
	private LocalDateTime date;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "cart", referencedColumnName = "cartid")
    private FoodCart cart;
	
	@Column(name="orderstatus")
	private String orderstatus;
	
	@Transient
	@OneToOne(mappedBy = "orderdetails",cascade = CascadeType.ALL, orphanRemoval = true,fetch = FetchType.LAZY)
    private Bill bill;
	
	public OrderDetails()
	{}

	public OrderDetails(long orderid, LocalDateTime date, FoodCart cart, String orderstatus) {
		super();
		this.orderid = orderid;
		this.date = date;
		this.cart = cart;
		this.orderstatus = orderstatus;
	}

	public long getOrderid() {
		return orderid;
	}

	public LocalDateTime getDate() {
		return date;
	}

	public FoodCart getCart() {
		return cart;
	}

	public String getOrderstatus() {
		return orderstatus;
	}

	public void setOrderid(long orderid) {
		this.orderid = orderid;
	}

	public void setDate(LocalDateTime date) {
		this.date = date;
	}

	public void setCart(FoodCart cart) {
		this.cart = cart;
	}

	public void setOrderstatus(String orderstatus) {
		this.orderstatus = orderstatus;
	}
	
	

}
