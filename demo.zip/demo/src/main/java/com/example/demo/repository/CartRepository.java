package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.FoodCart;
import com.example.demo.model.Item;

public interface CartRepository extends JpaRepository<FoodCart,Long>{

	//FoodCart saveItem(long id,Item item);

	//FoodCart saveItemToItemList(long id, Item item);
	
}
