package com.example.demo.service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.Bill;
import com.example.demo.model.FoodCart;
import com.example.demo.model.Item;
import com.example.demo.repository.CartRepository;
import com.example.demo.repository.ItemRepository;
@Service
public class CartService {
	@Autowired
	CartRepository cartrepository;
	@Autowired
	ItemRepository itemrepository;
	
	public List<FoodCart> viewCarts()
	{
		List<FoodCart> list = cartrepository.findAll();
		if(list.size() > 0) {
            return list;
        } else {
            return new ArrayList<FoodCart>();
        }
	}
	
	@Transactional
	public FoodCart addCart(FoodCart cart) {
		return cartrepository.save(cart);
	}
	
	@Transactional
	public long removeCart(long theId) {
		cartrepository.deleteById((long) theId);
		return theId;
	}
	
	@Transactional
	public FoodCart updateCart(FoodCart cart)
	{
		long getid=cart.getCartid();
		if(getid!=0)
			cartrepository.deleteById(getid);
		else
			throw new RuntimeException("no bill found to update");
		return cartrepository.save(cart);
	}

	@Transactional
	public Optional<FoodCart> getCartById(long id)
	{
		return cartrepository.findById(id);
	}
	
	@Transactional
	public FoodCart addItemtoCart(FoodCart cart,long itemid)
	{
		Item item=itemrepository.getById(itemid);
		List<Item> li=cart.getItems();
		li.add(item);
		cart.setItems(li);
		return cartrepository.save(cart);
	}
}
