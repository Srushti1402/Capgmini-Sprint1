package com.example.demo.controller;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.model.Item;
import com.example.demo.model.Restaurant;
import com.example.demo.repository.ItemRepository;
import com.example.demo.repository.RestaurantRepository;

@RestController
@RequestMapping("/api")
public class ItemController {
	@Autowired
	ItemRepository repository;
	@Autowired
	RestaurantRepository restaurantrepository;
	//get all items
	@GetMapping("/items")
	public ResponseEntity<List<Item>> getAllItems()
	{
		List<Item> list=repository.findAll();
		return new ResponseEntity<List<Item>>(list,new HttpHeaders(),HttpStatus.OK);
	}
	
	//get item by id
	//@GetMapping("/items/{id}")
	@GetMapping("/items/{id}")
	  public ResponseEntity<Item> getTutorialById(@PathVariable("id") long id) {
	    Item tutorial = repository.findById(id)
	        .orElseThrow(() -> new RuntimeException("Not found Tutorial with id = " + id));
	    return new ResponseEntity<>(tutorial, HttpStatus.OK);
	  }
	
	//create item
	@RequestMapping(value="/items",method=RequestMethod.POST)
	public Item addItem(@RequestBody Item item)
	{
	        return (repository.save(item));
	}
	
	//delete item by id
	//@DeleteMapping("/items/{id}")
	@RequestMapping(value="/items/{id}",method=RequestMethod.DELETE)
	public String deleteItem(@PathVariable long id)
	{
		Optional<Item> i=repository.findById(id);
		if(i==null)
			throw new RuntimeException("item Id not found");
		repository.deleteById(id);
		return "deleted item "+id;
	}
	
	@GetMapping("/restaurants/{restaurantid}/items")
	  public ResponseEntity<List<Item>> getAllItemsByRestaurantId(@PathVariable(value = "restaurantid") long restaurantid) {
	    if (!restaurantrepository.existsById(restaurantid)) {
	      throw new RuntimeException("Not found item with id = " + restaurantid);
	    }
	    List<Item> comments = repository.findByRestaurantRestaurantid(restaurantid);
	    return new ResponseEntity<List<Item>>(comments,new HttpHeaders(),HttpStatus.OK);
	  }
	
	
}
