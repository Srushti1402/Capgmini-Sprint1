package com.example.demo.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name="restaurant1")
public class Restaurant {
	
	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="restaurantid")
	private long restaurantid;
	
	@Column(name ="restaurantname")
	private String restaurantName;
	
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "itemid",referencedColumnName = "itemid",nullable = false)
	  //@OnDelete(action = OnDeleteAction.CASCADE)
	private Item item;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "addressid", referencedColumnName = "addressid")
    private Address address;
	
	@Transient
	@OneToMany(targetEntity=Item.class, mappedBy="restaurant",cascade=CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
	//@JsonManagedReference
	private List<Item> items = new ArrayList<>();

	public Restaurant()
	{ }

	public Restaurant(String restaurantName,Address address) {
		this.restaurantName = restaurantName;
		this.address=address;
	}
	
	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public long getRestaurantid() {
		return restaurantid;
	}

	public String getRestaurantName() {
		return restaurantName;
	}

	public long getItem() {
		return item.getItemid();
	}

	public void setRestaurantid(long restaurantid) {
		this.restaurantid = restaurantid;
	}

	public void setRestaurantName(String restaurantName) {
		this.restaurantName = restaurantName;
	}

	public void setItem(long itemid) {
		this.item.setItemid(itemid);
	}
	
	
}
