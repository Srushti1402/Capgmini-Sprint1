package com.example.demo.model;

import javax.persistence.*;
@Entity
@Table(name="category")
public class Category {
	
	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="catid")
	private long catid;
	
	@Column(name="catname")
	private String catname;
	
	@Transient
	@OneToOne(mappedBy = "category",cascade = CascadeType.ALL, orphanRemoval = true,fetch = FetchType.LAZY)
    private Item item;
	
	public Category() 
	{}

	public Category(long catid, String categoryname) {
		super();
		this.catid = catid;
		this.catname = categoryname;
	}

	public long getCatid() {
		return catid;
	}

	public String getCategoryname() {
		return catname;
	}

	public void setCatid(long catid) {
		this.catid = catid;
	}

	public void setCategoryname(String categoryname) {
		this.catname = categoryname;
	}

	

}
