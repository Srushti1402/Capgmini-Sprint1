package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Bill;
import com.example.demo.model.Restaurant;
import com.example.demo.service.BillService;

@RestController
@RequestMapping("/bill")
public class BillController {
	@Autowired
	BillService service;
	
	@GetMapping("/allbills")
	public ResponseEntity<List<Bill>> getAllBills()
	{
		List<Bill> list=service.viewBills();
		return new ResponseEntity<List<Bill>>(list,new HttpHeaders(),HttpStatus.OK);
	}
	
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public Bill addBill(@RequestBody Bill bill)
	{
		return service.addBill(bill);
	}
	
	@RequestMapping(value="/delete/{id}",method=RequestMethod.DELETE)
	public String deleteBill(@PathVariable long id)
	{
		Optional<Bill> i=service.getBillById(id);
		if(i==null)
			throw new RuntimeException("item Id not found");
		service.removeBill(id);
		return "deleted bill "+id;
	}
	
	/*public List<Bill> viewBillByCustomerId(long id)
	{
		return service.viewBillByCustomerId(id);
	}*/

}
