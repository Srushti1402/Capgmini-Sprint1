package com.example.demo.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name="item1")
public class Item {
	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="itemid")
	private long itemid;
	
	@Column(name="itemname")
	private String itemName;
	
	@Column(name="quantity")
	private int quantity;
	
	@Column(name="cost")
	private double cost;
	
	@Transient
	@OneToMany(targetEntity=Restaurant.class, mappedBy="item",cascade=CascadeType.ALL, orphanRemoval = true,fetch = FetchType.LAZY)
	//@JsonManagedReference
	//@JsonIgnore
	private List<Restaurant> restaurants = new ArrayList<>();
	
	/*@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "cart",referencedColumnName = "cartid",nullable = false)
	  //@OnDelete(action = OnDeleteAction.CASCADE)
	  //@JsonIgnore
	private FoodCart cart;*/
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "category", referencedColumnName = "catid")
    private Category category;
	
	

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "restaurant",referencedColumnName = "restaurantid",nullable = false)
	  //@OnDelete(action = OnDeleteAction.CASCADE)
	private Restaurant restaurant=new Restaurant();
	
	
	public Item()
	{}

	public Item(String itemName, int quantity, double cost,Category cat) {
		super();
		this.itemName = itemName;
		this.quantity = quantity;
		this.cost = cost;
		this.category=cat;
	}
	
	public Restaurant getRestaurant() {
		return restaurant;
	}

	public void setRestaurant(int id) {
		this.restaurant.setRestaurantid(id);
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public long getItemid() {
		return itemid;
	}

	public String getItemName() {
		return itemName;
	}

	public int getQuantity() {
		return quantity;
	}

	public double getCost() {
		return cost;
	}

	public void setItemid(long itemid) {
		this.itemid = itemid;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}
	
	

}
