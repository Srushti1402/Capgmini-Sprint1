package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Item;
import com.example.demo.model.Restaurant;
import com.example.demo.repository.ItemRepository;
import com.example.demo.repository.RestaurantRepository;

@RestController
@RequestMapping("/api")
public class RestaurantController {
	@Autowired
	private ItemRepository itemrepository;
	@Autowired
	private RestaurantRepository restrepository;

	//get all restaurants with given itemid
	@GetMapping("/items/{itemid}/restaurants")
	  public ResponseEntity<List<Restaurant>> getAllRestaurantByItemId(@PathVariable(value = "itemid") long itemid) {
	    if (!itemrepository.existsById(itemid)) {
	      throw new RuntimeException("Not found item with id = " + itemid);
	    }
	    List<Restaurant> comments = restrepository.findByItemItemid(itemid);
	    return new ResponseEntity<List<Restaurant>>(comments,new HttpHeaders(),HttpStatus.OK);
	  }
	
	@GetMapping("/restaurants")
	public ResponseEntity<List<Restaurant>> getAllRestaurants()
	{
		List<Restaurant> list=restrepository.findAll();
		return new ResponseEntity<List<Restaurant>>(list,new HttpHeaders(),HttpStatus.OK);
	}
	
	@GetMapping("/allitems/{name}")
	public ResponseEntity<List<Restaurant>> getAllItemsByRestaurantName(@PathVariable String name)
	{
		List<Restaurant> list=restrepository.findByRestaurantName(name);
		return new ResponseEntity<List<Restaurant>>(list,new HttpHeaders(),HttpStatus.OK);
	}
	
	@RequestMapping(value="/restaurants",method=RequestMethod.POST)
	public Restaurant addRestaurant(@RequestBody Restaurant rest)
	{
	        return (restrepository.save(rest));
	}
	
	@RequestMapping(value="/restaurants/{id}",method=RequestMethod.DELETE)
	public String deleteRestaurant(@PathVariable long id)
	{
		Optional<Restaurant> i=restrepository.findById(id);
		if(i==null)
			throw new RuntimeException("item Id not found");
		restrepository.deleteById(id);
		return "deleted restaurant "+id;
	}
}
