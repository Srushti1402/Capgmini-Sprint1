package com.example.demo.controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.model.Category;
import com.example.demo.repository.CategoryRepository;
import com.example.demo.service.CategoryService;

@RestController
@RequestMapping("/category")
public class CategoryController {
	@Autowired
	CategoryService service;
	@Autowired
	CategoryRepository repository;
	
	@GetMapping("/allcategories")
	public ResponseEntity<List<Category>> getAllCategory()
	{
		List<Category> list=service.viewAllCategories();
		return new ResponseEntity<List<Category>>(list,new HttpHeaders(),HttpStatus.OK);
	}
	
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public Category addCategory(@RequestBody Category cat)
	{
		//return service.addCategory(cat);
		return repository.save(cat);
	}
	
	@RequestMapping(value="/delete/{id}",method=RequestMethod.DELETE)
	public String deleteCategory(@PathVariable long id)
	{
		Optional<Category> i=service.getCategoryById(id);
		if(i==null)
			throw new RuntimeException("item Id not found");
		service.removeCategory(id);
		return "deleted restaurant "+id;
		
	}
}
