package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.Bill;
import com.example.demo.repository.BillRepository;

@Service
public class BillService {
	@Autowired
	BillRepository billrepository;
	
	public List<Bill> viewBills()
	{
		List<Bill> list = billrepository.findAll();
		if(list.size() > 0) {
            return list;
        } else {
            return new ArrayList<Bill>();
        }
	}
	
	@Transactional
	public Bill addBill(Bill bill) {
		return billrepository.save(bill);
	}
	
	@Transactional
	public long removeBill(long id) {
		billrepository.deleteById((long) id);
		return id;
	}
	
	@Transactional
	public Bill updateBill(Bill bill)
	{
		long getid=bill.getBillid();
		if(getid!=0)
			billrepository.deleteById(getid);
		else
			throw new RuntimeException("no bill found to update");
		return billrepository.save(bill);
	}
	
	@Transactional
	public Optional<Bill> getBillById(long id)
	{
		return billrepository.findById(id);
	}
	
	/*@Transactional
	public List<Bill> viewBillByCustomerId(long id)
	{
		return billrepository.findAllByCustomerCustomer(id);
	}*/

}
