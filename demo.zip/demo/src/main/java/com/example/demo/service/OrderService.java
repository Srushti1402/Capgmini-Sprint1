package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.Bill;
import com.example.demo.model.OrderDetails;
import com.example.demo.repository.OrderRepository;

@Service
public class OrderService {
	@Autowired
	OrderRepository orderrepository;
	
	public List<OrderDetails> viewAllOrderDetails()
	{
		List<OrderDetails> list = orderrepository.findAll();
		if(list.size() > 0) {
            return list;
        } else {
            return new ArrayList<OrderDetails>();
        }
	}
	
	@Transactional
	public OrderDetails addOrderDetails(OrderDetails orderDetails) {
		return orderrepository.save(orderDetails);
	}
	
	@Transactional
	public long removeOrderDetails(long theId) {
		orderrepository.deleteById((long) theId);
		return theId;
	}

	
	@Transactional
	public OrderDetails updateOrderDetails(OrderDetails orderDetails)
	{
		long getid=orderDetails.getOrderid();
		if(getid!=0)
			orderrepository.deleteById(getid);
		else
			throw new RuntimeException("no order found to update");
		return orderrepository.save(orderDetails);
	}
	
	@Transactional
	public Optional<OrderDetails> getBillById(long id)
	{
		return orderrepository.findById(id);
	}
}