package com.example.demo.model;

import java.time.LocalDateTime;

import javax.persistence.*;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
@Entity
@Table(name="bill")
public class Bill {
	
	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="billid")
	private long billid;
	
	@Column(name="billdate")
	private LocalDateTime date;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "orderid", referencedColumnName = "orderid")
    private OrderDetails orderdetails;
	
	@Column(name="totalitem")
	private int totalitem;
	
	@Column(name="totalcost")
	private double totalcost;
	
	public Bill()
	{}

	public Bill(long billid, LocalDateTime date, OrderDetails orderdetails, int totalitem, double totalcost) {
		super();
		this.billid = billid;
		this.date = date;
		this.orderdetails = orderdetails;
		this.totalitem = totalitem;
		this.totalcost = totalcost;
	}

	public long getBillid() {
		return billid;
	}

	public LocalDateTime getDate() {
		return date;
	}

	public OrderDetails getOrderdetails() {
		return orderdetails;
	}

	public int getTotalitem() {
		return totalitem;
	}

	public double getTotalcost() {
		return totalcost;
	}

	public void setBillid(long billid) {
		this.billid = billid;
	}

	public void setDate(LocalDateTime date) {
		this.date = date;
	}

	public void setOrderdetails(OrderDetails orderdetails) {
		this.orderdetails = orderdetails;
	}

	public void setTotalitem(int totalitem) {
		this.totalitem = totalitem;
	}

	public void setTotalcost(double totalcost) {
		this.totalcost = totalcost;
	}
	
	

}
