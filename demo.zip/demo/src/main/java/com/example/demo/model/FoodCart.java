package com.example.demo.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name="foodcart")
public class FoodCart {
	
	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="cartid")
	private long cartid;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "customerid", referencedColumnName = "customerid")
    private Customer customer;
	
	@Transient
	@OneToMany(targetEntity=Item.class, mappedBy="cart",cascade=CascadeType.ALL, fetch = FetchType.LAZY,orphanRemoval = true)
	//@JoinColumn(name = "itemid",referencedColumnName = "itemid",nullable = false)
	private List<Item> items = new ArrayList<>();
	
	@Transient
	@OneToOne(mappedBy = "cart",cascade = CascadeType.ALL, orphanRemoval = true,fetch = FetchType.LAZY)
    private OrderDetails orderdetails;
	
	public FoodCart()
	{}

	public FoodCart(long cartid, Customer customer, List<Item> items) {
		super();
		this.cartid = cartid;
		this.customer = customer;
		this.items = items;
	}

	public long getCartid() {
		return cartid;
	}

	public Customer getCustomer() {
		return customer;
	}

	public List<Item> getItems() {
		return items;
	}

	public void setCartid(long cartid) {
		this.cartid = cartid;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}
	
	

}
