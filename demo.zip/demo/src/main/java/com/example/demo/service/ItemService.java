package com.example.demo.service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.Bill;
import com.example.demo.model.Item;
import com.example.demo.repository.ItemRepository;

@Service
public class ItemService {
	@Autowired
	ItemRepository itemrepository;
	
	public List<Item> viewAllItems()
	{
		List<Item> list = itemrepository.findAll();
		if(list.size() > 0) {
            return list;
        } else {
            return new ArrayList<Item>();
        }
	}
	
	@Transactional
	public Item addItem(Item item) {
		return itemrepository.save(item);
	}
	
	@Transactional
	public long removeItem(long theId) {
		itemrepository.deleteById((long) theId);
		return theId;
	}
	
	@Transactional
	public Item updateItem(Item item)
	{
		long getid=item.getItemid();
		if(getid!=0)
			itemrepository.deleteById(getid);
		else
			throw new RuntimeException("no item found to update");
		return itemrepository.save(item);
	}
	
	@Transactional
	public Optional<Item> getBillById(long id)
	{
		return itemrepository.findById(id);
	}

}
