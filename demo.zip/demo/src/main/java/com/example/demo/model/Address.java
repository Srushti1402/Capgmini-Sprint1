package com.example.demo.model;

import javax.persistence.*;

@Entity
@Table(name="address")
public class Address {
	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="addressid")
	private long addressid;
	
	@Column(name="buildingname")
	private String buildingname;
	
	@Column(name="streetno")
	private String streetno;
	
	@Column(name="area")
	private String area;
	
	@Column(name="city")
	private String city;
	
	@Column(name="state")
	private String state;
	
	@Column(name="country")
	private String country;
	
	@Column(name="pin")
	private String pin;
	
	@Transient
	@OneToOne(mappedBy = "address" ,cascade = CascadeType.ALL, orphanRemoval = true,fetch = FetchType.LAZY)
    private Customer customer;
	
	@Transient
	@OneToOne(mappedBy = "address",cascade = CascadeType.ALL, orphanRemoval = true,fetch = FetchType.LAZY)
    private Restaurant restaurant;
	
	public Address()
	{ }

	public Address(long addressid,String buildingname, String streetno, String area, String city, String state, String country,
			String pin) {
		super();
		this.addressid=addressid;
		this.buildingname = buildingname;
		this.streetno = streetno;
		this.area = area;
		this.city = city;
		this.state = state;
		this.country = country;
		this.pin = pin;
	}

	public long getAddressid() {
		return addressid;
	}

	public String getPin() {
		return pin;
	}

	public void setAddressid(long addressid) {
		this.addressid = addressid;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public String getBuildingname() {
		return buildingname;
	}

	public String getStreetno() {
		return streetno;
	}

	public String getArea() {
		return area;
	}

	public String getCity() {
		return city;
	}

	public String getState() {
		return state;
	}

	public String getCountry() {
		return country;
	}

	public String getPincode() {
		return pin;
	}


	public void setBuildingname(String buildingname) {
		this.buildingname = buildingname;
	}

	public void setStreetno(String streetno) {
		this.streetno = streetno;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public void setPincode(String pincode) {
		this.pin = pin;
	}

	
	
	
	
	

}
