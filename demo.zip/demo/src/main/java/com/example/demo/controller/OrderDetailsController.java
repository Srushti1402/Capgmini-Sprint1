package com.example.demo.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Bill;
import com.example.demo.model.Customer;
import com.example.demo.model.OrderDetails;
import com.example.demo.repository.CustomerRepository;
import com.example.demo.repository.RestaurantRepository;
import com.example.demo.service.OrderService;

@RestController
@RequestMapping("/order")
public class OrderDetailsController {
	@Autowired
	OrderService service;
	
	@GetMapping("/allorders")
	public ResponseEntity<List<OrderDetails>> getAllOrders()
	{
		List<OrderDetails> list=service.viewAllOrderDetails();
		return new ResponseEntity<List<OrderDetails>>(list,new HttpHeaders(),HttpStatus.OK);
	}
	
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public OrderDetails addOrder(@RequestBody OrderDetails order)
	{
		return service.addOrderDetails(order);
	}

}
